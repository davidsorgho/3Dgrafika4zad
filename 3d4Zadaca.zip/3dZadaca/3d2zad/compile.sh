g++ -std=c++17 containers.cpp src/glad.c -I./include -L./lib -o gl -lglfw
